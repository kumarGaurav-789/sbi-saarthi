# SBI Saarthi
### Your AI Co-Pilot for Life's Financial Moments

**SBI Hackathon @ GFF 2026 — Idea Submission**
**Theme:** Digital Engagement · Agentic AI & Emerging Tech

> An agentic AI engagement layer that senses life events in customer behaviour and turns them into timely, trustworthy banking conversations — instead of generic, calendar-driven marketing.

---

## 📌 The Problem

SBI's engagement is massive in scale, but reactive in nature:

- **480M+** customer accounts — the largest base of any Indian bank
- **<10%** of eligible customers act on generic cross-sell offers
- A typical **3–6 month** gap between a real life event (new job, marriage, loan closure, retirement) and any relevant bank outreach

Today, engagement is built around the calendar, not the customer. Marketing pushes are mass-blasted on fixed cycles — the same offer to a fresher and a retiree — while the signals that actually predict a banking need already sit inside transaction data, unused. By the time a relevant offer arrives, a fintech app has often already won the moment.

## 💡 Our Solution

**SBI Saarthi** turns transaction signals into the right conversation, at the right moment, through a three-step loop:

| Step | Agent | What it does |
|------|-------|---------------|
| 1. **Sense** | Signal Agent | Detects life-event signals from transaction & behaviour patterns — salary jump, EMI closure, large deposit, new dependent — with full customer consent |
| 2. **Reason** | Reasoning Agent | An LLM grounds each signal in the customer's profile + SBI's product catalog (RAG) to decide the single best next action |
| 3. **Engage** | Conversation Agent | Reaches out in plain language on app / WhatsApp, explains the "why now," answers questions, and completes onboarding conversationally |

A fourth, always-on **Compliance & Trust Agent** checks every recommendation against RBI guidance and consent state before it ever reaches the customer.

## 🏗️ Agentic Architecture

```
 ┌────────────┐      ┌──────────────┐      ┌────────────────┐
 │   Signal   │ ───▶ │  Reasoning   │ ───▶ │  Conversation   │ ───▶ Customer
 │   Agent    │      │    Agent     │      │     Agent       │     (App / WhatsApp / SMS)
 └────────────┘      └──────────────┘      └────────────────┘
       │                    │                      │
       └────────────────────┴──────────────────────┘
                             │
                    ┌──────────────────┐
                    │ Compliance & Trust │  ← validates every step
                    │       Agent        │     (RBI rules, consent, audit trail)
                    └──────────────────┘
```

**Sits on top of existing rails — no rip and replace:**
- Core banking & transaction streams (read-only, consented)
- YONO app, SMS, and WhatsApp Business API for delivery
- RM dashboard for human oversight on every high-value nudge

## 🎯 Life Events We Act On

| Life Event | Trigger Signal | Recommended Action |
|---|---|---|
| **New Job / Salary Jump** | Sustained salary increase | Savings-to-investment migration (SIP, mutual funds) |
| **Marriage / New Dependent** | Joint-account activity, dependent addition | Term life & family floater health cover |
| **Loan Closure / Large Payoff** | EMI stoppage, lump-sum credit | Reinvestment, FD laddering, top-up loan options |
| **Approaching Retirement** | Age + contribution patterns | Pension, annuity, senior-citizen savings education |

## 🛠️ Tech Stack

| Layer | Approach |
|---|---|
| **Orchestration** | LLM-based multi-agent orchestration (Claude / GPT-class models) for reasoning and conversation generation |
| **Data Layer** | Event-driven streaming pipeline over transaction data; vector store for customer context & product catalog (RAG) |
| **Delivery** | YONO app inbox, SMS, and WhatsApp Business API — channel chosen per customer preference & urgency |
| **Trust & Compliance** | Rules engine mapped to RBI guidelines, consent ledger, and full audit trail for every agent decision |

## 📈 Why This Wins

| Dimension | Mass Campaigns (Today) | Basic Chatbot | SBI Saarthi |
|---|---|---|---|
| Personalisation | Generic, segment-level | Mostly templated | Individual, signal-driven |
| Timing | Fixed calendar campaigns | Static FAQ responses | Real-time, event-triggered |
| Channel behaviour | One-way broadcast | Reactive only | Proactive two-way conversation |
| Compliance | Manual review per campaign | Not built in | Dedicated agent, every message |

*Projected cross-sell conversion uplift is illustrative (based on industry benchmarks for event-triggered engagement) and would be validated against real or synthetic data during the Prototype Development phase.*

## 🗺️ From Idea to Prototype

1. **Idea Submission** *(this repo)* — problem, agentic architecture, and use cases for the Digital Engagement theme
2. **Prototype Build** — synthetic transaction dataset → working Signal + Reasoning + Conversation agent pipeline
3. **Channel Demo** — live WhatsApp/chat demo showing a detected life event turning into a real conversation
4. **RM Dashboard** — oversight view so relationship managers can review, edit, or approve high-value nudges

## 📂 Repository Contents

- `README.md` — this document
- `docs/idea-deck.pptx` — full idea submission slide deck

## 🔒 IP & Compliance Note

IP for this solution remains with the participating team throughout, per the hackathon terms. SBI's role in later phases would be deployment & commercialisation collaboration. The design assumes explicit customer consent for behavioural signal use and full alignment with RBI data-privacy guidance.

---

**Team:** *[Add your team name here]*
**Contact:** *[Add your email here]*
